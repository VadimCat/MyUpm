﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Ji2.Camera
{
    public class CameraSource
    {
        public UnityEngine.Camera MainCamera => _mainCamera;
        private UnityEngine.Camera _mainCamera;

        public event Action<UnityEngine.Camera> CameraChanged;
        
        public CameraSource()
        {
            ChangeCamera();
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
        
        private void OnSceneLoaded(Scene arg0, LoadSceneMode loadSceneMode)
        {
            ChangeCamera();
        }
        
        private void ChangeCamera()
        {
            var camera = UnityEngine.Camera.main;
            if (Equals(camera, _mainCamera))
            {
                return;
            }

            _mainCamera = camera;
            CameraChanged?.Invoke(_mainCamera);
        }
    }
}