# Ji2 Camera Source

Provides a simple `CameraSource` service that tracks `Camera.main` and raises
`CameraChanged` when the active camera changes.

## Usage

- Register `CameraSource` in your DI container (e.g. VContainer).
- Subscribe to `CameraChanged` or query `MainCamera`.
